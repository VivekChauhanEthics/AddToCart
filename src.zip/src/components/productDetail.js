import React from 'react';
import { useSelector } from 'react-redux';
import Header from './Header';

const CardStyle = {
    width: '650px',
    padding: '20px',
    borderRadius: '10px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 1)',
    height:"400px",
    display:"flex",
    marginTop:"20px",
}
const DiscriptionStyle = {
    display: '-webkit-box',
    WebkitBoxOrient: 'vertical',
    overflow: 'hidden',
    WebkitLineClamp: 2,  
    fontSize:"15px", 
    fontWeight:"400"
};
function ProductDetail() {
    // const dispatch = useDispatch();
    const product = useSelector((state) => state.product.productDetails);   
    console.log("product-detail", product);

    return (
        <>
        <Header />
        <div className="container-fluid" >
           <h1 className='text-center my-5'>Products Detail</h1>
           <div className='container d-flex justify-content-center'>
                <div className='py-4'>
                {product.map((item) => (
                        <div style={CardStyle} key={item.id}>
                            <div><img src={item.image} style={{width:"310px", height:"300px"}}/></div>
                            <div className='p-2 ms-5'>
                                <div className='mt-5'>
                                    <p className='text-center p-1 m-0' style={{fontSize:"20px", fontWeight:"600"}}> {item.title}</p>
                                    <p className='text-center p-1 m-0' style={{fontSize:"15px", fontWeight:"400"}}>{item.category}</p>
                                    <p className='text-center p-1 m-0' style={{fontSize:"15px", fontWeight:"600"}}>Price: <span className='text-success'>{item.price}</span></p>
                                    <p className='text-center p-1 m-0' style={DiscriptionStyle}>Description:{item.description}</p>
                                    <p className='text-center pb-2 m-0' style={{fontSize:"15px", fontWeight:"400"}}>Rating:<span className='bg-success text-white'> {item.rating.rate} </span></p>
                                </div>
                                <div className='text-center mt-3 d-flex gap-2'>
                                    <button size="small" style={{fontSize:"15px", color:"green"}}>Buy Now</button>
                                    <button size="small" style={{fontSize:"15px"}}>Add To Card</button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
        </>
    );
}

export default ProductDetail;
