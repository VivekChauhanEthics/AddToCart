// import React, { useEffect } from 'react';
// import { Link } from 'react-router-dom';
// import { useDispatch, useSelector } from 'react-redux';
// import { fetchProduct, addToCart, productDetail  } from '../redux/action/action';
// import Header from './Header';

// const CardStyle = {
//     width: '350px',
//     padding: '20px',
//     borderRadius: '10px',
//     boxShadow: '0 4px 8px rgba(0, 0, 0, 1)',
//     height:"310px"
// }
// const clampStyle = {
//     display: '-webkit-box',
//     WebkitBoxOrient: 'vertical',
//     overflow: 'hidden',
//     WebkitLineClamp: 2,  
//     fontSize:"20px",
//     fontWeight:"600"
// };
// const CategoryclampStyle = {
//     display: '-webkit-box',
//     WebkitBoxOrient: 'vertical',
//     overflow: 'hidden',
//     WebkitLineClamp: 1,  
//     fontSize:"15px", 
//     fontWeight:"400"
// };

// function Home() {
//     const dispatch = useDispatch();
//     const product = useSelector((state) => state.product.product);   
//     // console.log("product-component", product);
    
//     useEffect(() => {
//         dispatch(fetchProduct());
//     }, [dispatch]);
    
//     const handleAddToCart = (product) => {
//         dispatch(addToCart(product));
//     };

//     const handleProductDetail = (productDetails) => {
//         dispatch(productDetail(productDetails));
//     };

//     return (
//         <>
//         <Header />
//         <div className="container-fluid" >
//            <h1 className='text-center my-5'>Products List</h1>
//            <div className='container' style={{overflow:"scroll",  overflowY:"hidden"}}>
//                 <div className='d-flex gap-4 py-5'>
//                     {product.map((item) => (
//                         <div style={CardStyle} key={item.id}>
//                         <Link to="/productDetail" onClick={()=> handleProductDetail(item)}><div><img src={item.image} style={{width:"140px", height:"100px", cursor:"pointer"}}/></div></Link>
//                             <div className=''>
//                                 <p className='text-center p-0 m-0' style={clampStyle}> {item.title}</p>
//                                 <p className='text-center p-0 m-0' style={CategoryclampStyle}>{item.category}</p>
//                                 <p className='text-center p-0 m-0' style={{fontSize:"15px", fontWeight:"600"}}>Price: <span className='text-success'>{item.price}</span></p>
//                                 <p className='text-center pb-2 m-0' style={{fontSize:"15px", fontWeight:"400"}}>Rating: {item.rating.rate}</p>
//                             </div>
//                             <div className='text-center '>
//                                 <button size="small" style={{fontSize:"15px"}}  onClick={() => handleAddToCart(item)}>Add To Card</button>
//                             </div>
//                         </div>
//                     ))}
//                 </div>
//             </div>
//         </div>
//         <div className="container-fluid" >
//            <div className='container' style={{overflow:"scroll", overflowY:"hidden"}}>
//                 <div className='d-flex gap-5 py-5'>
//                     {product.map((item) => (
//                         <div style={CardStyle} key={item.id}>
//                         <Link to="/productDetail" onClick={()=> handleProductDetail(item)}><div><img src={item.image} style={{width:"140px", height:"100px", cursor:"pointer"}}/></div></Link>
//                             <div className=''>
//                                 <p className='text-center p-0 m-0' style={clampStyle}> {item.title}</p>
//                                 <p className='text-center p-0 m-0' style={CategoryclampStyle}>{item.category}</p>
//                                 <p className='text-center p-0 m-0' style={{fontSize:"15px", fontWeight:"600"}}>Price: <span className='text-success'>{item.price}</span></p>
//                                 <p className='text-center pb-2 m-0' style={{fontSize:"15px", fontWeight:"400"}}>Rating: {item.rating.rate}</p>
//                             </div>
//                             <div className='text-center '>
//                                 <button size="small" style={{fontSize:"15px"}}  onClick={() => handleAddToCart(item)}>Add To Card</button>
//                             </div>
//                         </div>
//                     ))}
//                 </div>
//             </div>
//         </div>
//         </>
//     );
// }

// export default Home;

import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProduct, addToCart, productDetail } from '../redux/action/action';
import Header from './Header';

const CardStyle = {
  width: '350px',
  padding: '20px',
  borderRadius: '10px',
  boxShadow: '0 4px 8px rgba(0, 0, 0, 1)',
  height: '310px',
};
const clampStyle = {
  display: '-webkit-box',
  WebkitBoxOrient: 'vertical',
  overflow: 'hidden',
  WebkitLineClamp: 2,
  fontSize: '20px',
  fontWeight: '600',
};
const CategoryclampStyle = {
  display: '-webkit-box',
  WebkitBoxOrient: 'vertical',
  overflow: 'hidden',
  WebkitLineClamp: 1,
  fontSize: '15px',
  fontWeight: '400',
};

function Home() {
  const dispatch = useDispatch();
  const products = useSelector((state) => state.product.product);
  const [searchInput, setSearchInput] = useState('');

  useEffect(() => {
    dispatch(fetchProduct());
  }, [dispatch]);

  const handleAddToCart = (product) => {
    dispatch(addToCart(product));
  };

  const handleProductDetail = (productDetails) => {
    dispatch(productDetail(productDetails));
  };

  const handleSearchInputChange = (e) => {
    setSearchInput(e.target.value);
  };

  const filteredProducts = products.filter((product) =>
    product.title.toLowerCase().includes(searchInput.toLowerCase())
  );

  return (
    <>
      <Header />
      <div className="container-fluid">
        
        <h1 className="text-center my-5">Products List</h1>
        <div className="d-flex justify-content-center ">
          <input
            type="text"
            placeholder="Search products..."
            value={searchInput}
            onChange={handleSearchInputChange}
            className='border'
          />
          <div>
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/>
            </svg>
          </div>
        </div>
        <div className="container" style={{ overflow: 'scroll', overflowY: 'hidden' }}>
          <div className="d-flex gap-4 py-5">
            {filteredProducts.map((item) => (
              <div style={CardStyle} key={item.id}>
                <Link to="/productDetail" onClick={() => handleProductDetail(item)}>
                  <div>
                    <img src={item.image} style={{ width: '140px', height: '100px', cursor: 'pointer' }} />
                  </div>
                </Link>
                <div className="">
                  <p className="text-center p-0 m-0" style={clampStyle}>
                    {' '}
                    {item.title}
                  </p>
                  <p className="text-center p-0 m-0" style={CategoryclampStyle}>
                    {item.category}
                  </p>
                  <p className="text-center p-0 m-0" style={{ fontSize: '15px', fontWeight: '600' }}>
                    Price: <span className="text-success">{item.price}</span>
                  </p>
                  <p className="text-center pb-2 m-0" style={{ fontSize: '15px', fontWeight: '400' }}>
                    Rating: {item.rating.rate}
                  </p>
                </div>
                <div className="text-center ">
                  <button size="small" style={{ fontSize: '15px' }} onClick={() => handleAddToCart(item)}>
                    Add To Card
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export default Home;
