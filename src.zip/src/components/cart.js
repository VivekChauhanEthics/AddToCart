import React, { useState, useEffect } from 'react';
import Header from './Header';
import { useSelector, useDispatch } from 'react-redux';
import { removeFromCart } from '../redux/action/action';

const CartContStyle = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
};

const CarTStyle = {
  borderRadius: '10px',
  boxShadow: '0 4px 8px rgba(0, 0, 0, 1)',
  height: 'auto',
  border: '1px solid',
  padding: '10px',
  width: '400px',
};

const AmountCarTStyle = {
  height: '500px',
  border: '1px solid',
  padding: '10px',
  width: '30%',
};

function Cart() {
  const [quantity, setQuantity] = useState(1);
  const [totalAmount, setTotalAmount] = useState(0);
  const [ discount, setDiscount ] = useState()

  const cart = useSelector((state) => state.product.cart);
  console.log("cart ", cart)
  const dispatch = useDispatch();

  const calculateTotalAmount = () => {
    let totalAmount = 0;
    cart.forEach((item) => {
      totalAmount += item.price * quantity;
    });
    return totalAmount;
  };

  const TotalDiscount = ()=>{
    setDiscount(25);
  }

  useEffect(() => {
    // Update total amount when quantity or cart changes
    setTotalAmount(calculateTotalAmount());
    TotalDiscount();
  }, [quantity, cart]);

 
  const handleRemoveFromCart = (productId) => {
    dispatch(removeFromCart(productId));
  };

  const QuantityDec = () =>{
    if (quantity > 1) {
        setQuantity(quantity - 1);
    }
  }
  const QuantityInc =()=>{
    if (quantity < 5) {
        setQuantity(quantity + 1);
    }
  }


  return (
    <>
      <Header />
      <div className='d-flex'>
        <div className='text-center my-3 me-auto'>
          <h1 className='my-2'>Cart Items</h1>
          <ul style={CartContStyle}>
            {cart.map((item) => (
              <div
                className='d-flex justify-content-center my-3'
                key={item.id}
                style={CarTStyle}
              >
                <div>
                  <img
                    src={item.image}
                    style={{ width: '150px', height: '180px' }}
                    alt={item.title}
                  />
                </div>
                <div>
                  <div className=''>
                    <p
                      className='text-center p-0 m-0'
                      style={{ fontSize: '15px', fontWeight: '600' }}
                    >
                      {item.title}
                    </p>
                    <p
                      className='text-center p-0 m-0'
                      style={{ fontSize: '15px', fontWeight: '400' }}
                    >
                      {item.category}
                    </p>
                    <p
                      className='text-center p-0 m-0'
                      style={{ fontSize: '15px', fontWeight: '600' }}
                    >
                      Price: <span className='text-success'>{item.price}</span>
                    </p>
                    <p
                      className='text-center pb-2 m-0'
                      style={{ fontSize: '15px', fontWeight: '400' }}
                    >
                      Quantity:
                      <button onClick={()=> QuantityDec()} className='border-0'>
                        -
                      </button>
                      {quantity}
                      <button onClick={()=> QuantityInc()} className='border-0'>
                        +
                      </button>
                    </p>
                    <p
                      className='text-center pb-2 m-0'
                      style={{ fontSize: '15px', fontWeight: '500' }}
                    >
                      Rating: {item.rating.rate}
                    </p>
                  </div>
                  <div className='text-center mb-3'>
                    <button
                      size='small'
                      style={{ fontSize: '15px' }}
                      onClick={() => handleRemoveFromCart(item.id)}
                    >
                      Remove Item
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </ul>
        </div>
        <div style={AmountCarTStyle}>
            <h2>Total Items</h2>
            <p>Quantity: {cart.reduce((total, item) => total + item.quantity, 0)}</p>
            <p>Amount: ₹{totalAmount}</p>
            <p>Discount: ₹ -{discount}</p>
            <p>Dilevery Charge: ₹ 0.0</p>
            <h5>Total Amount: ₹{totalAmount - discount} /-</h5>
        </div>
      </div>
    </>
  );
}

export default Cart;
