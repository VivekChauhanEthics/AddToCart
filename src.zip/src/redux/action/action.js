export const fetchProduct = () => async(dispatch) => {
    // fetch('https://fakestoreapi.com/products')
    //   .then((res) => res.json())
    //   .then((product) =>
    //     dispatch({
    //       type: 'FETCH_PRODUCT',
    //       payload: product,
    //     })
    //   );

      try {
        const response = await fetch('https://fakestoreapi.com/products');
        const product = await response.json();
        // Process the data
        dispatch({
          type: 'FETCH_PRODUCT',
          payload: product,
        })
      } catch (error) {
        console.error('Fetch API error:', error);
      }
};


export const addToCart = (product) => ({
  type: 'ADD_TO_CART',
  payload: product,
});

export const removeFromCart = (productId) => ({
  type: 'REMOVE_FROM_CART',
  payload: productId,
});

export const updateQuantity = (productId, newQuantity) => {
  return {
    type: 'UPDATE_QUANTITY',
    payload: {
      productId,
      newQuantity,
    },
  };
};

export const productDetail = (productDetails) => ({
  type: 'PRODUCT_DETAIL',
  payload: productDetails,
});